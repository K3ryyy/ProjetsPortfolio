#!/usr/bin/php

<?php
   $conf = file('regions.txt');
   $prem_ligne = fgets($conf);
   $elem_prem_ligne = explode(',', $prem_ligne);

   $lines = file("text.csv");
   $parts = fgets($lines);
    $parts = explode("|", $parts);
    $parts = str_replace("^","\n\t",$parts);

    $fic = file("Tableau.dat");
    $elem_prem_ligne = explode('|', $fic);
    $elem_prem_ligne = explode('|', $fic);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Feuille des résultats trimestriels</title>
   <link rel="stylesheet" href="style.css">
</head>
<body>
   <!-- PAGE DE COUVERTURE -->
   <section id="pageDeCouverture">
      <h1><?php echo htmlentities($elem_prem_ligne[0]) ?></h1>
      <h2><?php echo htmlentities($elem_prem_ligne[1]) ?>.</h2>
      <h2><?php echo htmlentities($elem_prem_ligne[2]) ?><sup>2</sup></h2>
      <h2><?php echo htmlentities($elem_prem_ligne[3]) ?> départements</h2>
      <div>
         <img id="logo" src="images/<?php echo htmlentities($elem_prem_ligne[4]) ?>" alt="logo Bretagne" title="logo Bretagne">
      </div>
      <div class="bottom"></div>
   </section>

   <!-- PAGE 1 -->
   <section id="page1">
         <h1>Résultats trimestriels 01-2023</h1> <!--<?php ?> PHP Date à calculer -->
         <div class="overflow">
            <h2><?php echo htmlentities($parts[1]) ?></h2>
            <p>
            <?php echo htmlentities($parts[2]) ?>   
            </p>

            <h3><?php echo htmlentities($parts[3]) ?> </h3>
            <p>
            <?php echo htmlentities($parts[4]) ?>  
            </p>

            <h2><?php echo htmlentities($parts[5]) ?> /h2>
            <p>
            <?php echo htmlentities($parts[6]) ?> 
            </p>
         </div>

         <table>
            <caption>Tableau comparatif des résultats de ce trimestre et de celui de l'année précédente </caption>
            <tr>
               <th>Produit</th>
               <th>01-2023<br >Ventes</th>
               <th>01-2023<br >CA</th>
               <th>01-2022<br >Ventes</th>
               <th>01-2022<br >CA</th>
               <th>Évolution du CA</th>
            </tr>
            <tr>
               <td>#1</td>
               <td>201</td>
               <td>289199</td>
               <td>190</td>
               <td>279102</td>
               <td class="evolutionPositive">103.62</td> <!--<?php ?>--> <!-- -->
            </tr>
            <tr>
               <td>#2</td>
               <td>90</td>
               <td>35019</td>
               <td>93</td>
               <td>34283</td>
               <td class="evolutionPositive">73.70</td> <!--<?php ?>-->
            </tr>
            <tr>
               <td>#3</td>
               <td>217</td>
               <td>191827</td>
               <td>290</td>
               <td>281923</td>
               <td class="evolutionNegative">66.55</td> <!--<?php ?>-->
            </tr>
            <tr>
               <td>#4</td>
               <td>182</td>
               <td>162719</td>
               <td>127</td>
               <td>108291</td>
               <td class="evolutionPositive">94.30</td> <!--<?php ?> À afficher en gras rouge ou en gras vert selon le résultat -->
            </tr>
         </table>

      <div class="bottom">13-01-2023 23:59</div><!--<?php ?>-->
   </section>

   <!-- PAGE 2 -->
   <section id="page2">
      <h1>Nos meilleurs professeurs du semestre</h1><!-- Penser à modifier-->
      <div id="galeriePhotos">
         <figure>
            <img classe="meilleurs_commerciaux" src="images/gqu.svg" alt="Gildas Quiniou" title="">
            <figcaption><span class="nom">Gildas Quiniou</span> <br >225K€</figcaption>
         </figure>
         <figure>
            <img classe="meilleurs_commerciaux" src="images/ama.svg" alt="Arnaud Martin" title="">
            <figcaption><span class="nom">Arnaud Martin</span><br >148K€</figcaption>
         </figure>
         <figure>
            <img classe="meilleurs_commerciaux" src="images/dno.svg" alt="Dieudonné Noulamoyènesilvouplé" title="">
            <figcaption><span class="nom">Dieudonné Noolam'wayen-Sivoplé</span><br >97K€</figcaption>
         </figure>
      </div>

      <div class="bottom">13-01-2023 23:59</div><!--<?php ?>-->
   </section>

   <!-- PAGE 3 -->
   <section id="page3">
      <a href="https://bigbrain.biz/FR-BRE">Lien vers le site de la société</a>
      <img src="images/qrcode.png" alt="QR Code" title="QR Code">
      <p>
         <em>Crédits</em><br ><br >
         <a href="https://fr.wikipedia.org/">Wikipédia<br >
         <a href="https://face.co">Face Co</a>
      </p>
      <div class="bottom">13-01-2023 23:59</div><!--<?php ?>-->
   </section>
</body>
</html>