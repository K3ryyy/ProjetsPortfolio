#!/usr/bin/php
<?php
	$files = scandir("./");
	$fichier = fopen("Tableau.dat", "w");
	
	print_r($files);
	
	foreach($files as $fic)
	{
		if(preg_match("#\.(txt)$#",strtolower($fic))){
			//$nom_fichier = file("Bretagne.txt");
			$nom_fichier = file($fic);
			foreach ($nom_fichier as $nom){
				if (strpos($nom,"Prod #") !== false){
					$tabTemp=explode('#', $nom);
					$tabTemp2=explode(',', $tabTemp[1]);
					$caEvo=(($tabTemp2[4]-$tabTemp2[2])/$tabTemp2[2])*100;
					$caEvo=round($caEvo, 2);
					$tabTemp[1] = rtrim($tabTemp[1]);
					$tabTemp[1] .= ",$caEvo%\n";
					print_r($tabTemp);
					fwrite($fichier, $tabTemp[1]);
				}    
			}
			fwrite($fichier, "|\n");
		}
			
	}
	
?>
